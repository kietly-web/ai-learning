---
name: feature-plan
description: Turn an approved SPEC.md into a concrete implementation plan, in plan mode
disable-model-invocation: true
---

Build an implementation plan from SPEC.md: $ARGUMENTS

1. Read SPEC.md at the project root. If it doesn't exist, stop and
   tell me to run `/feature-spec` first, or ask me to point you to
   where the spec lives if I already have one elsewhere.

2. Enter plan mode. Explore the parts of the codebase relevant to the
   spec: existing patterns to follow, files that will change, and
   anything the spec didn't account for. Do not make any edits during
   this step.

3. Propose a concrete implementation plan: which files change, in
   what order, and how each requirement in SPEC.md maps to a piece of
   the plan. If exploring the code reveals the spec is wrong,
   incomplete, or conflicts with something that already exists, say
   so explicitly and flag it — don't quietly work around it or
   silently reinterpret the spec.

4. Stop here. Do not implement anything. Tell me the plan is ready
   for review and that I can run `/feature-build` once I've approved
   it (or edited it directly if I opened it in my editor).
