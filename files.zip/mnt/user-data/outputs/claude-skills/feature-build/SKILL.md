---
name: feature-build
description: Implement an approved plan, verify it, and prepare it for commit
disable-model-invocation: true
---

Implement the approved plan for: $ARGUMENTS

1. Implement the plan we agreed on in the most recent plan-mode
   proposal. Follow existing code patterns and any conventions in
   CLAUDE.md.

2. Verify the work: run the test suite, build, and any other relevant
   checks. If SPEC.md defined an end-to-end way to verify the feature,
   run that too. Fix failures and re-run until everything passes. Show
   me the evidence (test output, build result, a screenshot for UI
   changes) rather than just asserting it's done.

3. Use a subagent to review the diff against SPEC.md in a fresh
   context. Check that every requirement is implemented, the listed
   edge cases have tests, and nothing outside the task's scope
   changed. Report only gaps that affect correctness or the stated
   requirements — skip style preferences.

4. Fix anything the review flagged, then stop. Summarize what changed
   and confirm it's ready for me to review and commit. Do not commit
   or open a PR yourself unless I explicitly ask you to.
