---
name: feature-spec
description: Interview the user to build a written spec for a new feature, saved to SPEC.md
disable-model-invocation: true
---

Discovery interview for a new feature: $ARGUMENTS

1. Interview me in detail using the AskUserQuestion tool. Ask about:
   - technical implementation approach
   - UI/UX expectations
   - edge cases and failure modes
   - what's explicitly out of scope
   - constraints, deadlines, and existing patterns to follow

   Don't ask me things you can answer yourself by reading the codebase
   first. Keep interviewing until this is genuinely covered — dig into
   the hard parts I might not have considered, not just the obvious
   first-pass questions. If my initial description is vague, treat
   that as the starting point for the interview, not a blocker — ask
   your way to clarity rather than asking me to clarify first.

2. Write the result to SPEC.md at the project root (create it if it
   doesn't exist, or append a new dated section if a SPEC.md for a
   different feature already exists). Include:
   - the feature name and a one-paragraph summary
   - files and interfaces likely involved
   - what's explicitly out of scope
   - an end-to-end way to verify the feature works when it's done —
     a concrete check, not "it should work correctly"

3. Stop here. Do not enter plan mode and do not write any code. Tell
   me the spec is ready for review and that I can run `/feature-plan`
   once I've approved or edited it.
